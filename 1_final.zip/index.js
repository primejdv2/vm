const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys')
const pino = require('pino')
const chalk = require('chalk')
const cfonts = require('cfonts')
const moment = require('moment')
const gradient = require('gradient-string')
const readline = require('readline')
const fs = require('fs')

require('./store.js')

const color = (text, color) => {
  return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

const question = (text) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  })
  return new Promise((resolve) => {
    rl.question(text, resolve)
  })
}

async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState(global.session)
  const { version } = await fetchLatestBaileysVersion()

  cfonts.say('WhatsApp Bot', {
    align: 'center',
    colors: ['blue', 'red'],
    background: 'transparent'
  })

  let opcion
  if (!fs.existsSync(`./${global.session}/creds.json`)) {
    opcion = await question(color('Seleccione una opción:\n') + 
      gradient('blue', 'red')('1. Con código QR\n') + 
      gradient('cyan', 'green')('2. Con código de emparejamiento\n'))
  }

  const client = makeWASocket({
    version,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: opcion == '1' ? true : false,
    auth: state
  })

  if (opcion === '2') {
    const phoneNumber = await question(color('Ingrese su número de WhatsApp: '))
    const code = await client.requestPairingCode(phoneNumber.trim())
    console.log(color('Código de emparejamiento: ', 'yellow') + chalk.bold(code))
  }

  client.ev.on('creds.update', saveCreds)

  client.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect } = update
    if (connection === 'close') {
      console.log(color('Conexión cerrada. Reconectando...', 'yellow'))
      connectToWhatsApp()
    }
    if (connection === 'open') {
      console.log(color('\n✅ Conectado correctamente a WhatsApp!', 'green'))
      console.log(color('Fecha: ', 'blue') + 
        moment().format('DD/MM/YY HH:mm:ss'))
    }
  })
}

connectToWhatsApp()