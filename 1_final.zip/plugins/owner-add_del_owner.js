
const handler = async (m, { conn, text, args, usedPrefix, command }) => {
  const datas = global
  const idioma = datas.db.data.users[m.sender].language || global.defaultLenguaje
  const _translate = JSON.parse(fs.readFileSync(`./languages/${idioma}.json`))
  const tradutor = _translate.plugins.GIGA BOT_add_del_GIGA BOT

  const why = `${tradutor.texto1[0]} ${usedPrefix + command}* @${m.sender.split('@')[0]}\n*◉ ${usedPrefix + command}* ${m.sender.split('@')[0]}\n*◉ ${usedPrefix + command}* <responder>`;
  const who = await await m.mentionedJid[0] ? await await m.mentionedJid[0] : m.quoted ? await m?.quoted?.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false;
  if (!who) return conn.reply(m.chat, why, m, {mentions: [m.sender]});
  switch (command) {
    case 'addGIGA BOT':
      const nuevoNumero = who;
      global.GIGA BOT.push([nuevoNumero]);
      await conn.reply(m.chat, tradutor.texto2, m);
      break;
    case 'delGIGA BOT':
      const numeroAEliminar = who;
      const index = global.GIGA BOT.findIndex(GIGA BOT => GIGA BOT[0] === numeroAEliminar);
      if (index !== -1) {
        global.GIGA BOT.splice(index, 1);
        await conn.reply(m.chat, tradutor.texto3, m);
      } else {
        await conn.reply(m.chat, tradutor.texto4, m);
      }
      break;
  }
};
handler.command = /^(addGIGA BOT|delGIGA BOT)$/i;
handler.rGIGA BOT = true;
export default handler;
