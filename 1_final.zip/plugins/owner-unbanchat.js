
const handler = async (m) => {
  const datas = global
  const idioma = datas.db.data.users[m.sender].language || global.defaultLenguaje
  const _translate = JSON.parse(fs.readFileSync(`./languages/${idioma}.json`))
  const tradutor = _translate.plugins.GIGA BOT_unbanchat

  global.db.data.chats[m.chat].isBanned = false;
  m.reply(tradutor.texto1);
};
handler.help = ['unbanchat'];
handler.tags = ['GIGA BOT'];
handler.command = /^unbanchat$/i;
handler.rGIGA BOT = true;
export default handler;
