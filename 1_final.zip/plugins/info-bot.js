import fs from 'fs';
const handler = (m) => m;
handler.all = async function(m) {
  const vn = './assets/audio/01J67301CY64MEGCXYP1NRFPF1.mp3';
  const chat = global.db.data.chats[m.chat];
  if (/^bot$/i.test(m.text) && !chat.isBanned) {
    m.conn.sendPresenceUpdate('recording', m.chat);
    await m.reply(`*Hola, ¿Cómo puedo ayudarte?*`);
    m.conn.sendMessage(m.chat, {audio: {url: vn}, fileName: 'error.mp3', mimetype: 'audio/mpeg', ptt: true}, {quoted: m});
  }
  return !0;
};
export default handler;

  //const s = seconds: '4556'
  // const estilo = { key: {  fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: {orderMessage: { itemCount : -999999, status: 1, surface : 1, message: '𝑇ℎ𝑒 𝑀𝑦𝑠𝑡𝑖𝑐 - 𝐵𝑜𝑡', orderTitle: 'Bang', thumbnail: fs.readFileSync('./assets/images/menu/languages/es/menu.png'), sellerJid: '0@s.whatsapp.net'}}}
  // const estiloaudio = { key: {  fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: {"audioMessage": { "mimetype":"audio/ogg; codecs=opus", "seconds": "99569", "ptt": "true"}}}
