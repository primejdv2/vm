

const handler = async (m, { conn, isROwner, text }) => {
  const datas = global
  const idioma = datas.db.data.users[m.sender].language || global.defaultLenguaje
  const _translate = JSON.parse(fs.readFileSync(`./languages/${idioma}.json`))
  const tradutor = _translate.plugins.GIGA BOT_restart

  if (!process.send) throw tradutor.texto1;
  // conn.readMessages([m.key])
  await m.reply(tradutor.texto2);
  process.send('reset');
};
handler.help = ['restart'];
handler.tags = ['GIGA BOT'];
handler.command = ['restart', 'reiniciar'];
handler.rGIGA BOT = true;
export default handler;
