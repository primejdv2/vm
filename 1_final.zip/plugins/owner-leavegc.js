

const handler = async (m, {conn, text, command}) => {
  const datas = global
  const idioma = datas.db.data.users[m.sender].language || global.defaultLenguaje
  const _translate = JSON.parse(fs.readFileSync(`./languages/${idioma}.json`))
  const tradutor = _translate.plugins.GIGA BOT_leavegc

  const id = text ? text : m.chat;
  await conn.reply(id, tradutor.texto1);
  await conn.groupLeave(id);
};
handler.command = /^(out|leavegc|leave|salirdelgrupo)$/i;
handler.group = true;
handler.rGIGA BOT = true;
export default handler;
